package ru.rsreu.brovkin0603.runner;

import java.io.File;

import com.prutzkow.resourcer.*;

import ru.rsreu.brovkin0603.entity.Sailor;
import ru.rsreu.brovkin0603.entity.comparator.ThreeSailorArraysDataComparator;
import ru.rsreu.brovkin0603.files.FileCreator;
import ru.rsreu.brovkin0603.files.FileHandler;
import ru.rsreu.brovkin0603.initializer.Initializer;

public class Runner {

	private static Resourcer resourcer = ProjectResourcer.getInstance();
	private static final String SOURCE = resourcer.getString("files.folder.source.name");
	private static final String MOVE = resourcer.getString("files.folder.move.name");
	private static final String COPY = SOURCE + File.separator + resourcer.getString("files.folder.copy.name");
	private static final String DATA_FILE = resourcer.getString("files.file.data.name")
			+ resourcer.getString("files.file.extension.separator") + resourcer.getString("files.file.data.extension");
	private static final String COPY_FILE = resourcer.getString("files.file.data.name")
			+ resourcer.getString("files.file.extension.separator")
			+ resourcer.getString("files.file.backup.extension");
	private Runner() {

	}

	public static void main(String[] args) {
		FileCreator.createFolder(SOURCE);
		FileCreator.createFolder(COPY);
		FileCreator.createFolder(MOVE);
		FileCreator.createFile(SOURCE, DATA_FILE);

		Sailor[] initializedSailors = Initializer.getSailors();
		FileHandler.writeFile(SOURCE + File.separator + DATA_FILE, initializedSailors);

		FileHandler.copyFile(SOURCE + File.separator + DATA_FILE, COPY + File.separator + COPY_FILE);
		FileHandler.moveFile(SOURCE + File.separator + DATA_FILE, MOVE + File.separator + DATA_FILE);

		Sailor[] firstCrewSailors = FileHandler.readFile(MOVE + File.separator + DATA_FILE);
		if (firstCrewSailors[0].getFullName() == "") {
			firstCrewSailors = FileHandler.readFile(SOURCE + File.separator + DATA_FILE);
		}
		Sailor[] secondCrewSailors = FileHandler.readFile(COPY + File.separator + COPY_FILE);

		System.out.printf(resourcer.getString("message.initialized.sailors"));
		printTableSailorsArray(initializedSailors);
		
		if (firstCrewSailors[0].getFullName() != "") {
			System.out.printf(resourcer.getString("message.first.crew.sailors"));
			printTableSailorsArray(firstCrewSailors);
		}
		
		if (secondCrewSailors[0].getFullName() != "") {
			System.out.printf(resourcer.getString("message.second.crew.sailors"));
			printTableSailorsArray(secondCrewSailors);
		}
		
		if (ThreeSailorArraysDataComparator.isThreeSailorArraysEqual(initializedSailors, firstCrewSailors, secondCrewSailors)) {
			System.out.printf(resourcer.getString("message.arrays.equal"));
		} else {
			System.out.printf(resourcer.getString("message.arrays.not.equal"));
		}
	}

	private static void printTableSailorsArray(Sailor[] initializedSailors) {
		System.out.printf(resourcer.getString("format.out"), resourcer.getString("message.full.name"),
				resourcer.getString("message.ship.name"), resourcer.getString("message.post"));
		for (Sailor sailor : initializedSailors) {
			System.out.printf(resourcer.getString("format.out"), sailor.getFullName(), sailor.getShipName(),
					sailor.getPost());
		}
	}
}
