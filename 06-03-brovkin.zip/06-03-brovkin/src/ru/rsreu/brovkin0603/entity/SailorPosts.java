package ru.rsreu.brovkin0603.entity;

public enum SailorPosts {
	Captain,
	Boatswain,
	Machinist,
	Seaman,
	Engineer;
}
