package com.prutzkow.resourcer;

public interface Resourcer {
	String getString(String resourceKey);
}
