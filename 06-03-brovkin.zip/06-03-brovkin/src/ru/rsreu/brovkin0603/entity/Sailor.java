package ru.rsreu.brovkin0603.entity;

import java.io.Serializable;
import java.util.Objects;

import com.prutzkow.resourcer.*;

public class Sailor implements Comparable<Sailor>, Serializable {

	private static final long serialVersionUID = 1L;
	private String fullName;
	private String shipName;
	private SailorPosts post;

	public Sailor(String fullName, String shipName, SailorPosts post) {
		this.fullName = fullName;
		this.shipName = shipName;
		this.post = post;
	}

	public String getFullName() {
		return fullName;
	}

	public String getShipName() {
		return shipName;
	}

	public SailorPosts getPost() {
		return post;
	}

	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		return resourcer.getString("to.string.first.part") + this.fullName + resourcer.getString("to.string.second.part")
				+ this.shipName + resourcer.getString("to.string.third.part") + this.post
				+ resourcer.getString("to.string.fourth.part");
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.fullName, this.post, this.shipName);
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object == null) {
			return false;
		}
		if (this.getClass() != object.getClass()) {
			return false;
		}
		Sailor other = (Sailor) object;
		return Objects.equals(this.fullName, other.fullName) && Objects.equals(this.post, other.post)
				&& Objects.equals(this.shipName, other.shipName);
	}

	@Override
	public int compareTo(Sailor sailor) {
		return this.fullName.compareTo(sailor.fullName);
	}

}
