package ru.rsreu.brovkin0603.files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.brovkin0603.entity.Sailor;
import ru.rsreu.brovkin0603.entity.SailorPosts;
import ru.rsreu.brovkin0603.initializer.Initializer;

public class FileHandler {

	private FileHandler() {

	}

	public static void writeFile(String file, Sailor[] sailors) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		File currentFile = new File(file);
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(file);
			objectOutputStream = new ObjectOutputStream(fileOutputStream);
			for (Sailor sailor : sailors) {
				objectOutputStream.writeObject(sailor);
			}
			System.out.printf(resourcer.getString("message.data.write.file"), currentFile.getAbsolutePath());
		} catch (FileNotFoundException e) {
			getFileNotFoundMessage(resourcer, currentFile);
		} catch (IOException e) {
			getProblemReadWriteFileMessage(resourcer, currentFile);
		} finally {
			if (objectOutputStream != null) {
				try {
					objectOutputStream.close();
				} catch (IOException e) {
					getProblemCloseFileMessage(resourcer, currentFile);
				}
			}
		}
	}


	public static Sailor[] readFile(String file) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		File currentFile = new File(file);
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;
		Sailor[] sailors = new Sailor[1];
		sailors[0] = new Sailor("", "", SailorPosts.Captain);
		try {
			fileInputStream = new FileInputStream(file);
			objectInputStream = new ObjectInputStream(fileInputStream);
			sailors = new Sailor[Initializer.SAILORS.length];

			for (int item = 0; item < Initializer.SAILORS.length; item++) {
				sailors[item] = (Sailor) objectInputStream.readObject();
			}
			System.out.printf(resourcer.getString("message.file.read"), currentFile.getAbsolutePath());
		} catch (FileNotFoundException e) {
			getFileNotFoundMessage(resourcer, currentFile);
			return sailors;
		} catch (IOException e) {
			getProblemReadWriteFileMessage(resourcer, currentFile);
			return sailors;
		} catch (ClassNotFoundException e) {
			getClassNotFoundMessage(resourcer, currentFile);
		} finally {
			if (objectInputStream != null) {
				try {
					objectInputStream.close();
				} catch (IOException e1) {
					getProblemCloseFileMessage(resourcer, currentFile);
				}
			}
		}
		return sailors;
	}


	public static void copyFile(String fileCopyFrom, String fileCopyTo) {

		Resourcer resourcer = ProjectResourcer.getInstance();
		File currentFileFrom = new File(fileCopyFrom);
		File currentFileTo = new File(fileCopyTo);
		try {
			Files.copy(Paths.get(fileCopyFrom), Paths.get(fileCopyTo), StandardCopyOption.REPLACE_EXISTING);
			System.out.printf(resourcer.getString("message.file.copied"), currentFileFrom.getAbsolutePath(),
					currentFileTo.getAbsolutePath());
		} catch (IOException e) {
			getProblemReadWriteFileMessage(resourcer, currentFileTo);
		}
	}

	public static void moveFile(String fileMoveFrom, String fileMoveTo) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		File currentFileFrom = new File(fileMoveFrom);
		File currentFileTo = new File(fileMoveTo);
		Scanner input = new Scanner(System.in);
		String reply;
		
		do {
			System.out.printf(resourcer.getString("message.ask.for.move.reply"), currentFileFrom.getAbsolutePath(),
					currentFileTo.getAbsolutePath());
			reply = input.nextLine();
		} while (!isCorrectReply(resourcer, reply));
		input.close();
		
		if (reply.equals(resourcer.getString("reply.yes"))) {
			try {
				Files.move(Paths.get(fileMoveFrom), Paths.get(fileMoveTo), StandardCopyOption.REPLACE_EXISTING);
				System.out.printf(resourcer.getString("message.file.Moved"), currentFileFrom.getAbsolutePath(),
						currentFileTo.getAbsolutePath());
			} catch (FileNotFoundException e) {
				getFileNotFoundMessage(resourcer, currentFileFrom);
			} catch (IOException e) {
				getProblemReadWriteFileMessage(resourcer, currentFileFrom);
			}
		} else {
			System.out.printf(resourcer.getString("message.file.not.moved"), currentFileFrom.getAbsolutePath());
		}

	}

	private static void getFileNotFoundMessage(Resourcer resourcer, File currentFile) {
		System.out.printf(resourcer.getString("message.file.not.found"), currentFile.getAbsolutePath());
	}
	
	private static void getProblemReadWriteFileMessage(Resourcer resourcer, File currentFile) {
		System.out.printf(resourcer.getString("message.file.can.not.be.read"), currentFile.getAbsolutePath());
	}
	
	private static void getClassNotFoundMessage(Resourcer resourcer, File currentFile) {
		System.out.printf(resourcer.getString("message.file.has.incorrect.classes"), currentFile.getAbsolutePath());
	}

	private static void getProblemCloseFileMessage(Resourcer resourcer, File currentFile) {
		System.out.printf(resourcer.getString("message.file.can.not.close"), currentFile.getAbsolutePath());
	}
	
	private static boolean isCorrectReply(Resourcer resourcer, String reply) {
		return reply.equals(resourcer.getString("reply.yes")) || reply.equals(resourcer.getString("reply.no"));
	}
}
