package ru.rsreu.brovkin0603.files;

import java.io.File;
import java.io.IOException;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class FileCreator {
	
	private FileCreator() {
		
	}
	
	public static void createFile(String parentFile, String childFile) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		File file = new File(parentFile, childFile);
		try {
			file.createNewFile();
			System.out.printf(resourcer.getString("message.file.created"), file.getAbsolutePath());
		} catch (IOException e) {
			System.out.printf(resourcer.getString("message.file.can.not.be.created"), file.getAbsolutePath());
		}
	}
	
	public static void createFolder(String folderName) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		File folder = new File(folderName);
		try {
			folder.mkdir();
			System.out.printf(resourcer.getString("message.folder.created"), folder.getAbsolutePath());
		} catch (Exception e) {
			System.out.printf(resourcer.getString("message.file.can.not.be.created"), folder.getAbsolutePath());
		}
	}

}
