package ru.rsreu.brovkin0603.initializer;

import ru.rsreu.brovkin0603.entity.Sailor;
import ru.rsreu.brovkin0603.entity.SailorPosts;

public class Initializer {
	
	public static final Sailor CAPTAIN = new Sailor("Brovkin Artem Alekseevich", "Win", SailorPosts.Captain);
	public static final Sailor FIRST_ENGINNER = new Sailor("Ivanov Petr Alekseevich", "Win", SailorPosts.Engineer);
	public static final Sailor SECOND_ENGINNER = new Sailor("Petrov Artem Igorevich", "Lose", SailorPosts.Engineer);
	public static final Sailor BOATSWAIN = new Sailor("Semenov Mike Alexandrovich", "Win", SailorPosts.Boatswain);
	public static final Sailor MACHINIST = new Sailor("Sidorova Anna Alexandrovna", "Lose", SailorPosts.Machinist);
	public static final Sailor FIRST_SEAMAN = new Sailor("Golushko Sergei Fedorovich", "Some ship", SailorPosts.Seaman);
	public static final Sailor SECOND_SEAMAN = new Sailor("Grigorenko Grogoriy Grigorievich", "Win", SailorPosts.Seaman);
	public static final Sailor[] SAILORS = {CAPTAIN, FIRST_ENGINNER, SECOND_ENGINNER, BOATSWAIN, MACHINIST, FIRST_SEAMAN, SECOND_SEAMAN};
	
	private Initializer() {
		
	}

	public static Sailor[] getSailors() {
		return SAILORS;
	}
	
}
