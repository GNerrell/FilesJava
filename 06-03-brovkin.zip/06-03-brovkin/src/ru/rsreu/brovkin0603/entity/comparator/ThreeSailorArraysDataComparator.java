package ru.rsreu.brovkin0603.entity.comparator;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.brovkin0603.entity.Sailor;

public class ThreeSailorArraysDataComparator {

	private ThreeSailorArraysDataComparator() {

	}

	public static boolean isThreeSailorArraysEqual(Sailor[] firstSailorArray, Sailor[] secondSailorArray,
			Sailor[] thirdSailorArray) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		try {
			for (int item = 0; item < firstSailorArray.length; item++) {
				if (!isEqualHashCode(firstSailorArray, secondSailorArray, thirdSailorArray, item)) {
					return false;
				} else if (!isThreeSailorArraysEquals(firstSailorArray, secondSailorArray, thirdSailorArray, item)) {
					return false;
				}
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.printf(resourcer.getString("message.out.of.bounds"));
			return false;
		}
		return true;
	}

	private static boolean isThreeSailorArraysEquals(Sailor[] firstSailorArray, Sailor[] secondSailorArray,
			Sailor[] thirdSailorArray, int item) {
		return firstSailorArray[item].equals(secondSailorArray[item])
				&& firstSailorArray[item].equals(thirdSailorArray[item]);
	}

	private static boolean isEqualHashCode(Sailor[] firstSailorArray, Sailor[] secondSailorArray,
			Sailor[] thirdSailorArray, int item) {
		return firstSailorArray[item].hashCode() == secondSailorArray[item].hashCode()
				&& firstSailorArray[item].hashCode() == thirdSailorArray[item].hashCode();
	}
}
